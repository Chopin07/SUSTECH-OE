#ifndef __AD9833_H
#define __AD9833_H

#include "stm32f4xx.h"                  // Device header

#define TRI_WAVE 	0  		//������ǲ�
#define SIN_WAVE 	1		//������Ҳ�
#define SQU_WAVE 	2		//�������


void AD9833_WaveSeting_B(double frequence,unsigned int frequence_SFR,unsigned int WaveMode,unsigned int Phase );
void AD9833_WaveSeting_A(double frequence,unsigned int frequence_SFR,unsigned int WaveMode,unsigned int Phase );
void AD9833_Init_GPIO(void);
void AD9833_AmpSet_B(unsigned char amp);
void AD9833_AmpSet_A(unsigned char amp);


#endif
